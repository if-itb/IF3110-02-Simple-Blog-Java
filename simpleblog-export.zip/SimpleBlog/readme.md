# Simple Blog Java

Tugas 2 IF3110.

![Simple Blog](http://i655.photobucket.com/albums/uu275/sonnylazuardi/ss-5.jpg)

## Deskripsi

Gunakan template ini untuk membuat sebuah blog sederhana dengan menggunakan bahasa pemrograman PHP.

## Spesifikasi

Spesifikasi untuk Tugas II IF3110 dapat diakses pada pranala berikut:

https://www.dropbox.com/sh/ig1hf108ad9fqxi/AAA2PMjPFICSFo3ypdrHl39La?dl=0

## Deliverable

Tiap-tiap Kelompok Membuat Organizationnya masing-masing, dengan langkah:

1. Klik tanda Tambah disamping username pada Github, Pilih Create New Organization

2. Buat Organisasi dengan Nama : IF3110-II-Nomor_Kelompok . Nomor Kelompok dapat diakses [disini](https://docs.google.com/spreadsheets/d/1Y-FGJ_feIVYNRv-o0ycBXyfAiKMFXKA17cvw3Mhjd1A/edit?usp=sharing)

3. Masukkan email address salah satu anggota untuk billing email ( bebas ).

4. Undang anggota kelompok untuk menjadi anggota Organisasi.

5. Lakukan Fork Repository ini ke Organisasi yang baru dibentuk

6. Setelah selesai mengerjakan, lakukan Pull Request.

## Lisensi

&copy; 2014 Asisten IF3110

Yogi | [Sonny](http://github.com/sonnylazuardi) | Fathan | Renusa | Kelvin | Yanuar

Dosen: [Yudistira Dwi Wardhana](http://github.com/yudis)